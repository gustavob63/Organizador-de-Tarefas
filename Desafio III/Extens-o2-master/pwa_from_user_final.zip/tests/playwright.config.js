module.exports = { use: { headless: true }, testDir: './' };
