
console.log("Popup carregado com sucesso 🚀");
document.getElementById("botao").addEventListener("click", () => {
  document.getElementById("mensagem").textContent = " Você consegue!!";
})